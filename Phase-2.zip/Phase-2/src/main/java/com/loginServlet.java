package com;

import java.io.IOException;
import java.io.PrintWriter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class loginServlet extends HttpServlet {

	SessionFactory sessionFactory;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		
		sessionFactory = HibernateUtil.getSessionFactory();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		 if(isValidAdmin(email,password)) {
			 response.sendRedirect("dashboard.jsp");
		 }else {
			 response.sendRedirect("login.jsp?error=true");
		 } 
	}


	private boolean isValidAdmin(String email, String password) {
		boolean isValid =false;

		try {
			 Session session = sessionFactory.openSession();
			 Transaction tr = session.beginTransaction();
			 
			String hql = "from Admin where email= :email AND password = :password";
			Query query = session.createQuery(hql);
			 query.setParameter("email", email);
			 query.setParameter("password", password);
			 
			 Admin admin = (Admin) query.uniqueResult();
			 
			 tr.commit();
			 session.close();
			 
			 isValid = (admin != null);
		 }catch(Exception e) {
			 System.out.println(e.getMessage());
		 }
		
		return isValid;
	}

}

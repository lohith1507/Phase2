package com;

import java.util.Date;

public class Vitals {

	private long ID;
	private String name;
	private String phone;
	private int bplow;
	private int bphigh;
	private int spo2;
	private Date recordedon;

	public Vitals() {}
	
	public Vitals(long iD, String name, String phone, int bplow, int bphigh, int spo2, Date recordedon) {
		super();
		ID = iD;
		this.name = name;
		this.phone = phone;
		this.bplow = bplow;
		this.bphigh = bphigh;
		this.spo2 = spo2;
		this.recordedon = recordedon;
	}

	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getBplow() {
		return bplow;
	}

	public void setBplow(int bplow) {
		this.bplow = bplow;
	}

	public int getBphigh() {
		return bphigh;
	}

	public void setBphigh(int bphigh) {
		this.bphigh = bphigh;
	}

	public int getSpo2() {
		return spo2;
	}

	public void setSpo2(int spo2) {
		this.spo2 = spo2;
	}

	public Date getRecordedon() {
		return recordedon;
	}

	public void setRecordedon(Date recordedon) {
		this.recordedon = recordedon;
	}

	@Override
	public String toString() {
		return "\n Vitals [ID=" + ID + ", name=" + name + ", phone=" + phone + ", bplow=" + bplow + ", bphigh=" + bphigh
				+ ", spo2=" + spo2 + ", recordedon=" + recordedon + "] \n ";
	}	
}
